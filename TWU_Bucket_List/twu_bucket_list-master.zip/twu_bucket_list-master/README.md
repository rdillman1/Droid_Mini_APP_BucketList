# twu_bucket_list
Work together to build TWU bucket list android app

-- 01/14/2020
reviewed gitlab, created github accound
created repository. Played around learning android app dev. 

created basic recycler view and main launcher activity
scheduled to meet with partner next week

-- 01/19/2020
met with hjung 
reviewed what has been completed thus far. 
found we did not have a lot to go over scheduled to meet again next week
reviewed java classes
and created a solid xml template for the application 
additemActivity
bucketListActivity
add_item_layout

setup intents and recycler view to transfer between the two. 


-- 01/21/2020
hjung informed me that she will no longer be taking the course
I reviewed professors code examples and was able to setup my adaptor. 
I also read about using a model to do the legwork for getcommands. 
setup a model.java and implemented into my adaptor.java
was able to setup test recyclerview panels. 
confirmed all intents open to the right .java and xml. 

-- 01/31/2020
Reviewed milestone requirements
setup edititem.java and intent embeded into the add_item_layout.xml(recyclerview) 
this opened up to a edit_item xml

added a check button to add_item xml
This is meant to take the location Lat and long and present the location city at the bottom. 
Upon researching this capability. This idea may get scraped due to complexity. 



